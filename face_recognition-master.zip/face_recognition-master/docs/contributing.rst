.. include:: ../CONTRIBUTING.rst
